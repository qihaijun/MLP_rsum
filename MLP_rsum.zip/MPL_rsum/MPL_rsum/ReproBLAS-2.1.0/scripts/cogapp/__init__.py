""" Cog code generation tool.
    http://nedbatchelder.com/code/cog

    Copyright 2004-2015, Ned Batchelder.
"""

from __future__ import absolute_import

from .cogapp import *
