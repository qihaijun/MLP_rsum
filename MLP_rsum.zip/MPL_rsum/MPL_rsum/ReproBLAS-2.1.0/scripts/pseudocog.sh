#!/bin/bash
cp $3 $2
