export C_INCLUDE_PATH=~/qhj/libreproblas/include/:${C_INCLUDE_PATH}
export LIBRARY_PATH=~/qhj/libreproblas/lib:${LIBRARY_PATH}
#export LD_LIBRARY_PATH=/home/cl/OPENBLAS-EXT/OpenBLAS-0.3.14:${LD_LIBRARY_PATH}
