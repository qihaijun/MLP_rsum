#!/bin/bash

for i in `seq 1 10`
do
	echo "/****** The $i times ******/"
	a=$(date +%s%N|cut -c13-19|sed -r 's/0*([0-9])/\1/')
	echo $a
	./sum_sine $a
	echo
done
