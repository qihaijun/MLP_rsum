#include <binned.h>

/**
 * @brief binned complex double precision size
 *
 * @param fold the fold of the binned type
 * @return the size (in @c double) of the binned type
 *
 * @author Peter Ahrens
 * @date   27 Apr 2015
 */
int binned_zbnum(const int fold){
  return 4*fold;
}
