#ifndef TEST_TIME_H
#define TEST_TIME_H

void time_tic();

void time_toc();

double time_read();

void time_reset();
#endif
