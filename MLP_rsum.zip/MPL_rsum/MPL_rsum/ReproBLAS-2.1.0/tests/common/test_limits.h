#ifndef TEST_LIMITS_H
#define TEST_LIMITS_H

#define MAX_LINE 1024
#define MAX_NAME 1024

#endif
