the checks directory is for all tests that check the results of the library operations. Original tests by Diep Nguyen, tests reformatted by Peter Ahrens.
