make clean
make -j
make install
