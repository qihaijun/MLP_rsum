#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <sys/time.h>
#include <binned.h>
#include <binnedBLAS.h>
#include <reproBLAS.h>
#include <arm_neon.h>
#include <omp.h>

#include "../config.h"
#include "../src/common/common.h"

static struct timeval start;
static struct timeval end;

void tic(void){
  gettimeofday( &start, NULL );
}

double toc(void){
  gettimeofday( &end, NULL );

  return (end.tv_sec - start.tv_sec) + 1.0e-6 * (end.tv_usec - start.tv_usec);
}

void binnedBLAS_dmdsum2(const int fold, const int N, const double *X, const int incX, double *priY, const int incpriY, double *carY, const int inccarY){
  int N_block = 8;
  int deposits = 0;

  for(int i=0;i<N;i++)
	  printf("X[%d]=%le\n",i,X[i]);

  double bin1 = priY[0];
  double bin2 = priY[incpriY];
  double bin3 = priY[incpriY*2];
  double tbin1=0,tbin2=0,tbin3=0;

  #pragma omp parallel for firstprivate(X,N_block,deposits,bin1,bin2,bin3)
  for (int i = 0; i < N; i += N_block) {
	  double amax;
	  int j;
	  printf("threads id = %d, i = %d\n",omp_get_thread_num(),i);
	  //printf("Start parallel, %d %d\n",omp_get_num_threads(),omp_in_parallel());
	  if(!isnan(bin1)){
		N_block = MIN((N - i), N_block);
		amax = binnedBLAS_damax(N_block, X, incX);
	  	printf("threads id = %d, amax = %le\n",omp_get_thread_num(),amax);
		if (isinf(amax) || isinf(bin1)){
		  for (j = 0; j < N_block; j++){
		    bin1 += X[j * incX];
		  }
		}
		//if (isnan(bin1)){
		//  return;
		//  goto outloop;
		//} else if (isinf(bin1)){
		if (isinf(bin1)){
		  X += N_block * incX;
		  continue;
		}
		
		if (deposits + N_block > binned_DBENDURANCE) {
		  binned_dmrenorm(fold, priY, incpriY, carY, inccarY);
		  deposits = 0;
		}
		
		binned_dmdupdate(fold, amax, priY, incpriY, carY, inccarY);

        	long_double blp_tmp; (void)blp_tmp;
        	double cons_tmp; (void)cons_tmp;

		int i;
        	uint64x2_t bmt = veorq_u64(vreinterpretq_u64_f64(vdupq_n_f64(1.0)),vreinterpretq_u64_f64(vdupq_n_f64(1.0 + (DBL_EPSILON * 1.0001))));
        	float64x2_t vx_0, vx_1, vx_2, vx_3, vx_4, vx_5, vx_6, vx_7;
		float64x2_t vq_0;
		float64x2_t vs_0_0, vs_1_0, vs_2_0;

		vs_0_0 = vdupq_n_f64(bin1);
		vs_1_0 = vdupq_n_f64(bin2);
		vs_2_0 = vdupq_n_f64(priY[(incpriY * 2)]);
		
		vx_0 = vld1q_f64(X);
		vx_1 = vld1q_f64(X+2);
		vx_2 = vld1q_f64(X+4);
		vx_3 = vld1q_f64(X+6);

		for(i = 0; i + 16 < N_block; i += 16, X += 16){
			vx_4 = vld1q_f64(X+8);
			vx_5 = vld1q_f64(X+10);
			vx_6 = vld1q_f64(X+12);
			vx_7 = vld1q_f64(X+14);
			__asm__ volatile("prfm PLDL1KEEP, [%0, #(%1)]"::"r"(X),"i"(1024));
			vq_0 = vs_0_0;
			vs_0_0 = vaddq_f64(vs_0_0, vreinterpretq_f64_u64(vorrq_u64(vreinterpretq_u64_f64(vx_0),bmt)));
			vq_0 = vsubq_f64(vq_0, vs_0_0);
			vx_0 = vaddq_f64(vx_0, vq_0);
			vq_0 = vs_1_0;
			vs_1_0 = vaddq_f64(vs_1_0, vreinterpretq_f64_u64(vorrq_u64(vreinterpretq_u64_f64(vx_0),bmt)));
			vq_0 = vsubq_f64(vq_0, vs_1_0);
			vx_0 = vaddq_f64(vx_0, vq_0);
			vs_2_0 = vaddq_f64(vs_2_0, vreinterpretq_f64_u64(vorrq_u64(vreinterpretq_u64_f64(vx_0),bmt)));
			
			vq_0 = vs_0_0;
			vs_0_0 = vaddq_f64(vs_0_0, vreinterpretq_f64_u64(vorrq_u64(vreinterpretq_u64_f64(vx_1),bmt)));
			vq_0 = vsubq_f64(vq_0, vs_0_0);
			vx_1 = vaddq_f64(vx_1, vq_0);
			vq_0 = vs_1_0;
			vs_1_0 = vaddq_f64(vs_1_0, vreinterpretq_f64_u64(vorrq_u64(vreinterpretq_u64_f64(vx_1),bmt)));
			vq_0 = vsubq_f64(vq_0, vs_1_0);
			vx_1 = vaddq_f64(vx_1, vq_0);
			vs_2_0 = vaddq_f64(vs_2_0, vreinterpretq_f64_u64(vorrq_u64(vreinterpretq_u64_f64(vx_1),bmt)));
			
			vq_0 = vs_0_0;
			vs_0_0 = vaddq_f64(vs_0_0, vreinterpretq_f64_u64(vorrq_u64(vreinterpretq_u64_f64(vx_2),bmt)));
			vq_0 = vsubq_f64(vq_0, vs_0_0);
			vx_2 = vaddq_f64(vx_2, vq_0);
			vq_0 = vs_1_0;
			vs_1_0 = vaddq_f64(vs_1_0, vreinterpretq_f64_u64(vorrq_u64(vreinterpretq_u64_f64(vx_2),bmt)));
			vq_0 = vsubq_f64(vq_0, vs_1_0);
			vx_2 = vaddq_f64(vx_2, vq_0);
			vs_2_0 = vaddq_f64(vs_2_0, vreinterpretq_f64_u64(vorrq_u64(vreinterpretq_u64_f64(vx_2),bmt)));
			
			vq_0 = vs_0_0;
			vs_0_0 = vaddq_f64(vs_0_0, vreinterpretq_f64_u64(vorrq_u64(vreinterpretq_u64_f64(vx_3),bmt)));
			vq_0 = vsubq_f64(vq_0, vs_0_0);
			vx_3 = vaddq_f64(vx_3, vq_0);
			vq_0 = vs_1_0;
			vs_1_0 = vaddq_f64(vs_1_0, vreinterpretq_f64_u64(vorrq_u64(vreinterpretq_u64_f64(vx_3),bmt)));
			vq_0 = vsubq_f64(vq_0, vs_1_0);
			vx_3 = vaddq_f64(vx_3, vq_0);
			vs_2_0 = vaddq_f64(vs_2_0, vreinterpretq_f64_u64(vorrq_u64(vreinterpretq_u64_f64(vx_3),bmt)));
			
			vx_0 = vld1q_f64(X+16);
			vx_1 = vld1q_f64(X+18);
			vx_2 = vld1q_f64(X+20);
			vx_3 = vld1q_f64(X+22);

			vq_0 = vs_0_0;
			vs_0_0 = vaddq_f64(vs_0_0, vreinterpretq_f64_u64(vorrq_u64(vreinterpretq_u64_f64(vx_4),bmt)));
			vq_0 = vsubq_f64(vq_0, vs_0_0);
			vx_4 = vaddq_f64(vx_4, vq_0);
			vq_0 = vs_1_0;
			vs_1_0 = vaddq_f64(vs_1_0, vreinterpretq_f64_u64(vorrq_u64(vreinterpretq_u64_f64(vx_4),bmt)));
			vq_0 = vsubq_f64(vq_0, vs_1_0);
			vx_4 = vaddq_f64(vx_4, vq_0);
			vs_2_0 = vaddq_f64(vs_2_0, vreinterpretq_f64_u64(vorrq_u64(vreinterpretq_u64_f64(vx_4),bmt)));
			
			vq_0 = vs_0_0;
			vs_0_0 = vaddq_f64(vs_0_0, vreinterpretq_f64_u64(vorrq_u64(vreinterpretq_u64_f64(vx_5),bmt)));
			vq_0 = vsubq_f64(vq_0, vs_0_0);
			vx_5 = vaddq_f64(vx_5, vq_0);
			vq_0 = vs_1_0;
			vs_1_0 = vaddq_f64(vs_1_0, vreinterpretq_f64_u64(vorrq_u64(vreinterpretq_u64_f64(vx_5),bmt)));
			vq_0 = vsubq_f64(vq_0, vs_1_0);
			vx_5 = vaddq_f64(vx_5, vq_0);
			vs_2_0 = vaddq_f64(vs_2_0, vreinterpretq_f64_u64(vorrq_u64(vreinterpretq_u64_f64(vx_5),bmt)));
			
			vq_0 = vs_0_0;
			vs_0_0 = vaddq_f64(vs_0_0, vreinterpretq_f64_u64(vorrq_u64(vreinterpretq_u64_f64(vx_6),bmt)));
			vq_0 = vsubq_f64(vq_0, vs_0_0);
			vx_6 = vaddq_f64(vx_6, vq_0);
			vq_0 = vs_1_0;
			vs_1_0 = vaddq_f64(vs_1_0, vreinterpretq_f64_u64(vorrq_u64(vreinterpretq_u64_f64(vx_6),bmt)));
			vq_0 = vsubq_f64(vq_0, vs_1_0);
			vx_6 = vaddq_f64(vx_6, vq_0);
			vs_2_0 = vaddq_f64(vs_2_0, vreinterpretq_f64_u64(vorrq_u64(vreinterpretq_u64_f64(vx_6),bmt)));
			
			vq_0 = vs_0_0;
			vs_0_0 = vaddq_f64(vs_0_0, vreinterpretq_f64_u64(vorrq_u64(vreinterpretq_u64_f64(vx_7),bmt)));
			vq_0 = vsubq_f64(vq_0, vs_0_0);
			vx_7 = vaddq_f64(vx_7, vq_0);
			vq_0 = vs_1_0;
			vs_1_0 = vaddq_f64(vs_1_0, vreinterpretq_f64_u64(vorrq_u64(vreinterpretq_u64_f64(vx_7),bmt)));
			vq_0 = vsubq_f64(vq_0, vs_1_0);
			vx_7 = vaddq_f64(vx_7, vq_0);
			vs_2_0 = vaddq_f64(vs_2_0, vreinterpretq_f64_u64(vorrq_u64(vreinterpretq_u64_f64(vx_7),bmt)));
		}
        	if(i + 16 == N_block){
        	  vx_4 = vld1q_f64(X+8);
        	  vx_5 = vld1q_f64(X+10);
        	  vx_6 = vld1q_f64(X+12);
        	  vx_7 = vld1q_f64(X+14);

        	  vq_0 = vs_0_0;
        	  vs_0_0 = vaddq_f64(vs_0_0, vreinterpretq_f64_u64(vorrq_u64(vreinterpretq_u64_f64(vx_0),bmt)));
        	  vq_0 = vsubq_f64(vq_0, vs_0_0);
        	  vx_0 = vaddq_f64(vx_0, vq_0);
        	  vq_0 = vs_1_0;
        	  vs_1_0 = vaddq_f64(vs_1_0, vreinterpretq_f64_u64(vorrq_u64(vreinterpretq_u64_f64(vx_0),bmt)));
        	  vq_0 = vsubq_f64(vq_0, vs_1_0);
        	  vx_0 = vaddq_f64(vx_0, vq_0);
        	  vs_2_0 = vaddq_f64(vs_2_0, vreinterpretq_f64_u64(vorrq_u64(vreinterpretq_u64_f64(vx_0),bmt)));

        	  vq_0 = vs_0_0;
        	  vs_0_0 = vaddq_f64(vs_0_0, vreinterpretq_f64_u64(vorrq_u64(vreinterpretq_u64_f64(vx_1),bmt)));
        	  vq_0 = vsubq_f64(vq_0, vs_0_0);
        	  vx_1 = vaddq_f64(vx_1, vq_0);
        	  vq_0 = vs_1_0;
        	  vs_1_0 = vaddq_f64(vs_1_0, vreinterpretq_f64_u64(vorrq_u64(vreinterpretq_u64_f64(vx_1),bmt)));
        	  vq_0 = vsubq_f64(vq_0, vs_1_0);
        	  vx_1 = vaddq_f64(vx_1, vq_0);
        	  vs_2_0 = vaddq_f64(vs_2_0, vreinterpretq_f64_u64(vorrq_u64(vreinterpretq_u64_f64(vx_1),bmt)));

		  vq_0 = vs_0_0;
        	  vs_0_0 = vaddq_f64(vs_0_0, vreinterpretq_f64_u64(vorrq_u64(vreinterpretq_u64_f64(vx_2),bmt)));
        	  vq_0 = vsubq_f64(vq_0, vs_0_0);
        	  vx_2 = vaddq_f64(vx_2, vq_0);
        	  vq_0 = vs_1_0;
        	  vs_1_0 = vaddq_f64(vs_1_0, vreinterpretq_f64_u64(vorrq_u64(vreinterpretq_u64_f64(vx_2),bmt)));
        	  vq_0 = vsubq_f64(vq_0, vs_1_0);
        	  vx_2 = vaddq_f64(vx_2, vq_0);
        	  vs_2_0 = vaddq_f64(vs_2_0, vreinterpretq_f64_u64(vorrq_u64(vreinterpretq_u64_f64(vx_2),bmt)));

        	  vq_0 = vs_0_0;
        	  vs_0_0 = vaddq_f64(vs_0_0, vreinterpretq_f64_u64(vorrq_u64(vreinterpretq_u64_f64(vx_3),bmt)));
        	  vq_0 = vsubq_f64(vq_0, vs_0_0);
        	  vx_3 = vaddq_f64(vx_3, vq_0);
        	  vq_0 = vs_1_0;
        	  vs_1_0 = vaddq_f64(vs_1_0, vreinterpretq_f64_u64(vorrq_u64(vreinterpretq_u64_f64(vx_3),bmt)));
        	  vq_0 = vsubq_f64(vq_0, vs_1_0);
        	  vx_3 = vaddq_f64(vx_3, vq_0);
        	  vs_2_0 = vaddq_f64(vs_2_0, vreinterpretq_f64_u64(vorrq_u64(vreinterpretq_u64_f64(vx_3),bmt)));

        	  vq_0 = vs_0_0;
        	  vs_0_0 = vaddq_f64(vs_0_0, vreinterpretq_f64_u64(vorrq_u64(vreinterpretq_u64_f64(vx_4),bmt)));
        	  vq_0 = vsubq_f64(vq_0, vs_0_0);
        	  vx_4 = vaddq_f64(vx_4, vq_0);
        	  vq_0 = vs_1_0;
        	  vs_1_0 = vaddq_f64(vs_1_0, vreinterpretq_f64_u64(vorrq_u64(vreinterpretq_u64_f64(vx_4),bmt)));
        	  vq_0 = vsubq_f64(vq_0, vs_1_0);
        	  vx_4 = vaddq_f64(vx_4, vq_0);
        	  vs_2_0 = vaddq_f64(vs_2_0, vreinterpretq_f64_u64(vorrq_u64(vreinterpretq_u64_f64(vx_4),bmt)));

        	  vq_0 = vs_0_0;
        	  vs_0_0 = vaddq_f64(vs_0_0, vreinterpretq_f64_u64(vorrq_u64(vreinterpretq_u64_f64(vx_5),bmt)));
        	  vq_0 = vsubq_f64(vq_0, vs_0_0);
        	  vx_5 = vaddq_f64(vx_5, vq_0);
        	  vq_0 = vs_1_0;
        	  vs_1_0 = vaddq_f64(vs_1_0, vreinterpretq_f64_u64(vorrq_u64(vreinterpretq_u64_f64(vx_5),bmt)));
        	  vq_0 = vsubq_f64(vq_0, vs_1_0);
        	  vx_5 = vaddq_f64(vx_5, vq_0);
        	  vs_2_0 = vaddq_f64(vs_2_0, vreinterpretq_f64_u64(vorrq_u64(vreinterpretq_u64_f64(vx_5),bmt)));

        	  vq_0 = vs_0_0;
        	  vs_0_0 = vaddq_f64(vs_0_0, vreinterpretq_f64_u64(vorrq_u64(vreinterpretq_u64_f64(vx_6),bmt)));
        	  vq_0 = vsubq_f64(vq_0, vs_0_0);
        	  vx_6 = vaddq_f64(vx_6, vq_0);
        	  vq_0 = vs_1_0;
        	  vs_1_0 = vaddq_f64(vs_1_0, vreinterpretq_f64_u64(vorrq_u64(vreinterpretq_u64_f64(vx_6),bmt)));
        	  vq_0 = vsubq_f64(vq_0, vs_1_0);
        	  vx_6 = vaddq_f64(vx_6, vq_0);
        	  vs_2_0 = vaddq_f64(vs_2_0, vreinterpretq_f64_u64(vorrq_u64(vreinterpretq_u64_f64(vx_6),bmt)));

        	  vq_0 = vs_0_0;
        	  vs_0_0 = vaddq_f64(vs_0_0, vreinterpretq_f64_u64(vorrq_u64(vreinterpretq_u64_f64(vx_7),bmt)));
        	  vq_0 = vsubq_f64(vq_0, vs_0_0);
        	  vx_7 = vaddq_f64(vx_7, vq_0);
        	  vq_0 = vs_1_0;
        	  vs_1_0 = vaddq_f64(vs_1_0, vreinterpretq_f64_u64(vorrq_u64(vreinterpretq_u64_f64(vx_7),bmt)));
        	  vq_0 = vsubq_f64(vq_0, vs_1_0);
        	  vx_7 = vaddq_f64(vx_7, vq_0);
        	  vs_2_0 = vaddq_f64(vs_2_0, vreinterpretq_f64_u64(vorrq_u64(vreinterpretq_u64_f64(vx_7),bmt)));
        	  i += 16, X += 16;
		}
        	if(i + 8 <= N_block){
        	  vx_0 = vld1q_f64(X);
        	  vx_1 = vld1q_f64(X+2);
        	  vx_2 = vld1q_f64(X+4);
        	  vx_3 = vld1q_f64(X+6);

        	  vq_0 = vs_0_0;
        	  vs_0_0 = vaddq_f64(vs_0_0, vreinterpretq_f64_u64(vorrq_u64(vreinterpretq_u64_f64(vx_0),bmt)));
        	  vq_0 = vsubq_f64(vq_0, vs_0_0);
        	  vx_0 = vaddq_f64(vx_0, vq_0);
        	  vq_0 = vs_1_0;
        	  vs_1_0 = vaddq_f64(vs_1_0, vreinterpretq_f64_u64(vorrq_u64(vreinterpretq_u64_f64(vx_0),bmt)));
        	  vq_0 = vsubq_f64(vq_0, vs_1_0);
        	  vx_0 = vaddq_f64(vx_0, vq_0);
        	  vs_2_0 = vaddq_f64(vs_2_0, vreinterpretq_f64_u64(vorrq_u64(vreinterpretq_u64_f64(vx_0),bmt)));

        	  vq_0 = vs_0_0;
        	  vs_0_0 = vaddq_f64(vs_0_0, vreinterpretq_f64_u64(vorrq_u64(vreinterpretq_u64_f64(vx_1),bmt)));
        	  vq_0 = vsubq_f64(vq_0, vs_0_0);
        	  vx_1 = vaddq_f64(vx_1, vq_0);
        	  vq_0 = vs_1_0;
        	  vs_1_0 = vaddq_f64(vs_1_0, vreinterpretq_f64_u64(vorrq_u64(vreinterpretq_u64_f64(vx_1),bmt)));
        	  vq_0 = vsubq_f64(vq_0, vs_1_0);
        	  vx_1 = vaddq_f64(vx_1, vq_0);
        	  vs_2_0 = vaddq_f64(vs_2_0, vreinterpretq_f64_u64(vorrq_u64(vreinterpretq_u64_f64(vx_1),bmt)));

        	  vq_0 = vs_0_0;
        	  vs_0_0 = vaddq_f64(vs_0_0, vreinterpretq_f64_u64(vorrq_u64(vreinterpretq_u64_f64(vx_2),bmt)));
        	  vq_0 = vsubq_f64(vq_0, vs_0_0);
        	  vx_2 = vaddq_f64(vx_2, vq_0);
        	  vq_0 = vs_1_0;
        	  vs_1_0 = vaddq_f64(vs_1_0, vreinterpretq_f64_u64(vorrq_u64(vreinterpretq_u64_f64(vx_2),bmt)));
        	  vq_0 = vsubq_f64(vq_0, vs_1_0);
        	  vx_2 = vaddq_f64(vx_2, vq_0);
        	  vs_2_0 = vaddq_f64(vs_2_0, vreinterpretq_f64_u64(vorrq_u64(vreinterpretq_u64_f64(vx_2),bmt)));

        	  vq_0 = vs_0_0;
        	  vs_0_0 = vaddq_f64(vs_0_0, vreinterpretq_f64_u64(vorrq_u64(vreinterpretq_u64_f64(vx_3),bmt)));
        	  vq_0 = vsubq_f64(vq_0, vs_0_0);
        	  vx_3 = vaddq_f64(vx_3, vq_0);
        	  vq_0 = vs_1_0;
        	  vs_1_0 = vaddq_f64(vs_1_0, vreinterpretq_f64_u64(vorrq_u64(vreinterpretq_u64_f64(vx_3),bmt)));
        	  vq_0 = vsubq_f64(vq_0, vs_1_0);
        	  vx_3 = vaddq_f64(vx_3, vq_0);
        	  vs_2_0 = vaddq_f64(vs_2_0, vreinterpretq_f64_u64(vorrq_u64(vreinterpretq_u64_f64(vx_3),bmt)));
        	  i += 8, X += 8;
        	}
        	if(i + 4 <= N_block){
        	  vx_0 = vld1q_f64(X);
        	  vx_1 = vld1q_f64(X+2);

        	  vq_0 = vs_0_0;
        	  vs_0_0 = vaddq_f64(vs_0_0, vreinterpretq_f64_u64(vorrq_u64(vreinterpretq_u64_f64(vx_0),bmt)));
        	  vq_0 = vsubq_f64(vq_0, vs_0_0);
        	  vx_0 = vaddq_f64(vx_0, vq_0);
        	  vq_0 = vs_1_0;
        	  vs_1_0 = vaddq_f64(vs_1_0, vreinterpretq_f64_u64(vorrq_u64(vreinterpretq_u64_f64(vx_0),bmt)));
        	  vq_0 = vsubq_f64(vq_0, vs_1_0);
        	  vx_0 = vaddq_f64(vx_0, vq_0);
        	  vs_2_0 = vaddq_f64(vs_2_0, vreinterpretq_f64_u64(vorrq_u64(vreinterpretq_u64_f64(vx_0),bmt)));

        	  vq_0 = vs_0_0;
        	  vs_0_0 = vaddq_f64(vs_0_0, vreinterpretq_f64_u64(vorrq_u64(vreinterpretq_u64_f64(vx_1),bmt)));
        	  vq_0 = vsubq_f64(vq_0, vs_0_0);
        	  vx_1 = vaddq_f64(vx_1, vq_0);
        	  vq_0 = vs_1_0;
        	  vs_1_0 = vaddq_f64(vs_1_0, vreinterpretq_f64_u64(vorrq_u64(vreinterpretq_u64_f64(vx_1),bmt)));
        	  vq_0 = vsubq_f64(vq_0, vs_1_0);
        	  vx_1 = vaddq_f64(vx_1, vq_0);
        	  vs_2_0 = vaddq_f64(vs_2_0, vreinterpretq_f64_u64(vorrq_u64(vreinterpretq_u64_f64(vx_1),bmt)));
        	  i += 4, X += 4;
        	}
        	if(i + 2 <= N_block){
        	  vx_0 = vld1q_f64(X);

        	  vq_0 = vs_0_0;
        	  vs_0_0 = vaddq_f64(vs_0_0, vreinterpretq_f64_u64(vorrq_u64(vreinterpretq_u64_f64(vx_0),bmt)));
        	  vq_0 = vsubq_f64(vq_0, vs_0_0);
        	  vx_0 = vaddq_f64(vx_0, vq_0);
        	  vq_0 = vs_1_0;
        	  vs_1_0 = vaddq_f64(vs_1_0, vreinterpretq_f64_u64(vorrq_u64(vreinterpretq_u64_f64(vx_0),bmt)));
        	  vq_0 = vsubq_f64(vq_0, vs_1_0);
        	  vx_0 = vaddq_f64(vx_0, vq_0);
        	  vs_2_0 = vaddq_f64(vs_2_0, vreinterpretq_f64_u64(vorrq_u64(vreinterpretq_u64_f64(vx_0),bmt)));
        	  i += 2, X += 2;
        	}
        	if(i < N_block){
        	  vx_0 = vld1q_f64(X);
        	  vsetq_lane_f64(0, vx_0, 1);

        	  vq_0 = vs_0_0;
        	  vs_0_0 = vaddq_f64(vs_0_0, vreinterpretq_f64_u64(vorrq_u64(vreinterpretq_u64_f64(vx_0),bmt)));
        	  vq_0 = vsubq_f64(vq_0, vs_0_0);
        	  vx_0 = vaddq_f64(vx_0, vq_0);

        	  vq_0 = vs_1_0;
        	  vs_1_0 = vaddq_f64(vs_1_0, vreinterpretq_f64_u64(vorrq_u64(vreinterpretq_u64_f64(vx_0),bmt)));
        	  vq_0 = vsubq_f64(vq_0, vs_1_0);
        	  vx_0 = vaddq_f64(vx_0, vq_0);

        	  vs_2_0 = vaddq_f64(vs_2_0, vreinterpretq_f64_u64(vorrq_u64(vreinterpretq_u64_f64(vx_0),bmt)));
        	  i++,X++;
        	}
        	float64x2_t s_tmp = vdupq_n_f64(bin1);
        	s_tmp = vsetq_lane_f64(0, s_tmp, 1);
        	vs_0_0 = vsubq_f64(vs_0_0, s_tmp);
        	bin1 = vgetq_lane_f64(vs_0_0, 0) + vgetq_lane_f64(vs_0_0, 1);

        	s_tmp = vdupq_n_f64(bin2);
        	s_tmp = vsetq_lane_f64(0, s_tmp, 1);
        	vs_1_0 = vsubq_f64(vs_1_0, s_tmp);
        	bin2 = vgetq_lane_f64(vs_1_0, 0) + vgetq_lane_f64(vs_1_0, 1);

        	s_tmp = vdupq_n_f64(bin3);
        	s_tmp = vsetq_lane_f64(0, s_tmp, 1);
        	vs_2_0 = vsubq_f64(vs_2_0, s_tmp);
        	bin3 = vgetq_lane_f64(vs_2_0, 0) + vgetq_lane_f64(vs_2_0, 1);
		deposits += N_block;

		#pragma omp atomic
		  tbin1 += bin1;
		#pragma omp atomic
		  tbin2 += bin2;
		#pragma omp atomic
		  tbin3 += bin3;
	}
  }
  priY[0] = tbin1;
  priY[incpriY] = tbin2;
  priY[incpriY*2] = tbin3;
  binned_dmrenorm(fold, priY, incpriY, carY, inccarY);
}

void binnedBLAS_dbdsum2(const int fold, const int N, const double *X, const int incX, double_binned *Y){
  binnedBLAS_dmdsum2(fold, N, X, incX, Y, 1, Y + fold, 1);
}

int main(int argc, char** argv){
  int n = (argc==2?atol(argv[1]):1000000);
  double *x = malloc(n * sizeof(double));
  double *x_shuffled = malloc(n * sizeof(double));
  double sum;
  double sum_shuffled;
  double elapsed_time;

  for(int i = 0; i < n; i++){
    x[i] = sin(2 * M_PI * (i / (double)n - 0.5));
  }

  for(int i = 0; i < n; i++){
    x_shuffled[i] = x[i];
  }
  double t;
  int r;
  for(int i = 0; i < n; i++){
    r = rand();
    t = x_shuffled[i];
    x_shuffled[i] = x_shuffled[i + (r % (n - i))];
    x_shuffled[i + (r % (n - i))] = t;
  }

  double_binned *isum = binned_dballoc(3);
  tic();
  binned_dbsetzero(3, isum);
  binnedBLAS_dbdsum2(3, n, x, 1, isum);
  sum = binned_ddbconv(3, isum);
  elapsed_time = toc();

  tic();
  binned_dbsetzero(3, isum);
  binnedBLAS_dbdsum2(3, n, x_shuffled, 1, isum);
  sum_shuffled = binned_ddbconv(3, isum);
  elapsed_time = toc();

  printf("%15s : %-8g : |%.17e - %.17e| = %g\n", "binnedBLAS_dbdsum", elapsed_time, sum, sum_shuffled, fabs(sum - sum_shuffled));

  free(x);
  free(x_shuffled);
  return 0;
}
