export C_INCLUDE_PATH=~/libreproblas/include/:${C_INCLUDE_PATH}
export LIBRARY_PATH=~/libreproblas/lib:${LIBRARY_PATH}
export LD_LIBRARY_PATH=/usr/local/lib:${LD_LIBRARY_PATH}
