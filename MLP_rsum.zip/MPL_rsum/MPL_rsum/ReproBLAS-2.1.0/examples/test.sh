#!/bin/bash

for i in `seq 0 129`
do
	export RE_CHA_SIZE=$((512+8*i))
	#echo "/****** The $i times ******/"
	#a=$(date +%s%N|cut -c13-19|sed -r 's/0*([0-9])/\1/')
	echo -n "RE_CHA_SIZE = "$((512+8*i))" "
	./sum_sine | grep reproBLAS_dsum |awk '{print $3}' 
#	grep reproBLAS_dsum tmp|awk 'BEGIN{sum=0}{sum += $3}END{print sum/10}'
done
