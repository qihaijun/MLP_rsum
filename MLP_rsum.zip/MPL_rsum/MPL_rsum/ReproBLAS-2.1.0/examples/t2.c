#include<stdio.h>
#include<stdlib.h>
#include<omp.h>

void main(){
	int sum=0;
	int n = 100;
	int *a = (int *)malloc(n*sizeof(int));
	for(int j=0;j<n;j++)
		a[j] = j;
#pragma omp parallel for
	for(int i=0;i<n;i+=10){
		sum += a[i];
		printf("thread id = %d, a[%d] = %d\n",omp_get_thread_num(),i,a[i]);
		printf("threads num = %d\n",omp_get_num_threads());	
		printf("is parallel or not %d\n",omp_in_parallel());
		
	}
}
