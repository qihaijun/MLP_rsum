
#REPRO_LIB=$1
#
#echo ${REPRO_LIB}
#
#a=`echo ${C_INCLUDE_PATH}|grep libreproblas`
#b=`echo ${LIBRARY_PATH}|grep libreproblas`
#c=`echo ${LD_LIBRARY_PATH}|grep libreproblas`
#
#if [ -n "$a" ]
#then
#	aa=${REPRO_LIB}/include:`echo ${a}|awk -F: '{for(i=2;i<NF;i++) printf $i":";print $NF}'`
#	unset C_INCLUDE_PATH
#	export C_INCLUDE_PATH=${aa}
#fi
#
#if [ -n "$b" ]	
#then
#	bb=${REPRO_LIB}/lib:`echo ${b}|awk -F: '{for(i=2;i<NF;i++) printf $i":";print $NF}'`
#	unset LIBRARY_PATH
#	export LIBRARY_PATH=${bb}
#fi
#
#if [ -n "$c" ]
#then
#	cc=${REPRO_LIB}/lib:`echo ${c}|awk -F: '{for(i=2;i<NF;i++) printf $i":";print $NF}'`
#	unset LD_LIBRARY_PATH
#	export LD_LIBRARY_PATH=${cc}
#fi
#
#
#export C_INCLUDE_PATH=${REPRO_LIB}/include:/usr/local/gcc830/include:${C_INCLUDE_PATH}
#export LIBRARY_PATH=${REPRO_LIB}/lib:${LIBRARY_PATH}
#export LD_LIBRARY_PATH=${REPRO_LIB}/lib:/usr/lib/llvm-8/lib:${LD_LIBRARY_PATH}
export C_INCLUDE_PATH=~/libreproblas/include:${C_INCLUDE_PATH}
#export PATH=/opt/mpi3/bin:${PATH}
export OMP_NUM_THREADS=2
