#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <sys/time.h>
#include <mpi.h>
#include <omp.h>
#include <binned.h>
#include <binnedBLAS.h>
#include <reproBLAS.h>
#include <binnedMPI.h>
#include <mpfr.h>

//gcc Rep_Sum_demo.c -o Rep_Sum_demo -lm -lmpfr -lgmp -O3

#define PRECISION            (700)
#define EPS_DOUBLE 2.0e-52
#define DIDEFAULTFOLD 3
#define MPI_REDOUBLE(fold) (fold*MPI_DOUBLE)


//计算时间
static struct timeval start;
static struct timeval end;
void tic(void){
  gettimeofday( &start, NULL );
}
double toc(void){
  gettimeofday( &end, NULL );
  return (end.tv_sec - start.tv_sec) + 1.0e-6 * (end.tv_usec - start.tv_usec);
}

//void MPI_Reduce_Reprosum(double *in, double *out, int count, MPI_Datatype datatype, MPI_Op op, int root, MPI_Comm communicator, int k){
//  double max_in[count];
//  int my_rank, my_size;
//  MPI_Comm_rank(communicator, &my_rank);
//  MPI_Comm_size(communicator, &my_size);
//  printf("%d / %d | in = %.16e out = %.16e\n",my_rank, my_size,*in,*out);	
//  MPI_Allreduce(in, max_in, count, MPI_DOUBLE, MPI_MAX, communicator);
//
//  double q1[count], q2[count], M1[count], M2[count];
//  double local_high[count], local_low[count], x_low[count];
//  double res_high[count], res_low[count];
//  for(int i=0; i < count; i++){
//    q1[i] = my_size*(max_in[i])/(1 - 2 * my_size * EPS_DOUBLE);
//    M1[i] = pow(2, ceil(log2(q1[i])));
//    q2[i] = my_size*( 2*EPS_DOUBLE *M1[i]) / (1 - 2*my_size*EPS_DOUBLE);
//    M2[i] = pow(2, ceil(log2(q2[i+1])));
//    local_high[i] = M1[i] + in[i] - M1[i];
//    x_low[i] = in[i] - local_high[i];
//    local_low[i] = M2[i] + x_low[i] - M2[i];
//  }
//  printf("%d / %d | local_high = %.16e local_low = %.16e\n",my_rank, my_size, *local_high, *local_low);
//  MPI_Reduce(local_high, res_high, count, datatype, op, root, communicator);
//  MPI_Reduce(local_low,  res_low, count, datatype, op, root, communicator);
//  printf("%d / %d | local_high = %.16e res_high = %.16e local_low = %.16e res_low = %.16e\n",my_rank, my_size, *local_high, *res_high, *local_low,  *res_low);
//  for(int i=0; i < count; i++){
//    out[i] = res_high[i] + res_low[i];
//  }
//}

void pval(char *c, double x){
	union du{
		double a;
		unsigned long b;
	} t;
	t.a = x;
	printf("%s = %le|%lx\n", c, t.a, t.b);

}

int checkarr(int n, double *x, double *y){
	int err=0;
	for(int i;i<n;i++)
		if(x[i]!=y[i]) err++;
	return err;
}

double MPI_Reprosum(double *local_x, long local_n, long incx){
  int rank;//, size;
  MPI_Comm_rank(MPI_COMM_WORLD, &rank);
  //MPI_Comm_size(MPI_COMM_WORLD, &size);
  //MPI_Request request;

  int i;
  //for(i=0;i<local_n;i++)
  //    printf("local_x[%d] = %le\n",i,local_x[i]);
  //int local_n = n / size;
  //int *local_n_list = NULL;
  //if(rank == 0){
  //        local_n_list = (int *)malloc(sizeof(int)*size);
  //	  for(i=0; i<size-1; i++)
  //	          local_n_list[i] = local_n;
  //	  local_n_list[size-1] = n-local_n*(size-1);
  //	  //for(i=0; i<size; i++)
  //        //        printf("local_n_list[%d] = %d\n",i, local_n_list[i]);
  //	  //for(i=0; i<n; i++)
  //        //        printf("x[%d] = %le\n",i, x[i]);
  //}

  //if(rank == size-1) local_n = n-local_n*(size-1);
  
  //double *local_x = malloc(local_n * sizeof(double));

  //if(rank == 0){
  //        //memcpy(local_x, x, local_n * sizeof(double));
  //        for(i=0; i<size;i++){
  //        	MPI_Isend(x, local_n_list[i], MPI_DOUBLE, i, 0, MPI_COMM_WORLD, &request);
  //      	x += local_n_list[i];
  //        }
  //        MPI_Recv(local_x, local_n, MPI_DOUBLE, 0, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
  //        free(local_n_list);
  //	  //for(i=0; i<local_n; i++)
  //        //        printf("rank = %d, local_x[%d] = %le\n",rank, i, local_x[i]);

  //}else{
  //	MPI_Recv(local_x, local_n, MPI_DOUBLE, 0, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
  	  //for(i=0; i<local_n; i++)
          //        printf("rank = %d, local_x[%d] = %le\n",rank, i, local_x[i]);

  //}

  int omp_threads;
  
  #pragma omp parallel
  omp_threads = omp_get_num_threads();
  
  //printf("out omp_threads = %d\n",omp_threads);
  int nsblks = omp_threads;
  nsblks = (nsblks==0)?1:nsblks;
  int blksInSblk = local_n/nsblks;
  int lastn = local_n-nsblks*blksInSblk;
  lastn = (lastn==0)?blksInSblk:(blksInSblk+lastn);
  //lastn = (lastn==0)?blksInSblk:lastn;
  //printf("rank = %d, nsblks = %d, blksInSblk = %d, lastn = %d\n", rank, nsblks, blksInSblk,lastn);

  double_binned *local_isum_list = binned_dballoc(DIDEFAULTFOLD*omp_threads);
  double_binned *local_isum = binned_dballoc(DIDEFAULTFOLD);
  //binned_dbsetzero(DIDEFAULTFOLD, local_isum);
  binned_dbsetzero(DIDEFAULTFOLD*omp_threads, local_isum_list);

  //double time;
  //tic();
  #pragma omp parallel for 
  for(i=0;i<omp_threads;i++){
	  //omp_threads = omp_get_num_threads();
	  int omp_id = omp_get_thread_num();
  	  //printf("in omp_threads = %d\n",omp_threads);

	  if(i<omp_threads-1){
	  	binnedBLAS_dbdsum(DIDEFAULTFOLD, blksInSblk, local_x+i*blksInSblk, 1, local_isum_list+2*i*DIDEFAULTFOLD);
		//printf("rank = %d i=%d, local_isum_list[%d]=%le\n", omp_id,i,2*i*DIDEFAULTFOLD,local_isum_list[2*i*DIDEFAULTFOLD]);
		//for(int j=0;j<DIDEFAULTFOLD;j++){
		//	pval("local_isum_list(py)", local_isum_list[2*i*DIDEFAULTFOLD+j]);
		//	pval("local_isum_list(cy)", local_isum_list[(2*i+1)*DIDEFAULTFOLD+j]);
		//}
		//for(int j=0;j<blksInSblk;j++)
		//	printf("local_x[%d]=%le\n",i*blksInSblk+j,local_x[i*blksInSblk+j]);
	  }else{
		//binnedBLAS_dbdsum(DIDEFAULTFOLD, blksInSblk, local_x+i*blksInSblk, 1, local_isum_list+2*i*DIDEFAULTFOLD);
		binnedBLAS_dbdsum(DIDEFAULTFOLD, lastn, local_x+i*blksInSblk, 1, local_isum_list+2*i*DIDEFAULTFOLD);
		//printf("rank = %d i=%d, local_isum_list[%d]=%le\n", omp_id,i,2*i*DIDEFAULTFOLD,local_isum_list[2*i*DIDEFAULTFOLD]);
		//for(int j=0;j<DIDEFAULTFOLD;j++){
		//	pval("local_isum_list(py)", local_isum_list[2*i*DIDEFAULTFOLD+j]);
		//	pval("local_isum_list(cy)", local_isum_list[(2*i+1)*DIDEFAULTFOLD+j]);
		//}
		//printf("local_x[i*blksInSblk+lastn-1]=%le\n",local_x[i*blksInSblk+lastn-1]);
		//for(int j=0;j<lastn;j++)
		//	printf("local_x[%d]=%le\n",i*blksInSblk+j,local_x[i*blksInSblk+j]);
	  }
	  //for(int j=0;j<2*DIDEFAULTFOLD*omp_threads;j++){
	  //        printf("rank=%d index=%d add=%lx ",i,j,local_isum_list+j);
	  //        pval("local_isum_list", local_isum_list[j]);
	  //}
  }
  //time = toc();
  //printf("\nomp compute time : %le\n",time);
  //printf("out omp_threads = %d\n",omp_get_num_threads());
  
  //tic();
  binned_dmdmset(DIDEFAULTFOLD, local_isum_list, 1, local_isum_list+DIDEFAULTFOLD, 1, local_isum, 1, local_isum+DIDEFAULTFOLD, 1);
  //pval("local_isum_list(py)", local_isum_list[0]);
  //pval("local_isum_list(cy)", local_isum_list[DIDEFAULTFOLD]);

  //pval("local_isum(py)", local_isum[0]);
  //pval("local_isum(cy)", local_isum[DIDEFAULTFOLD]);

  //static const double *bins;
  for(i=1;i<omp_threads;i++){
        binned_dmdmadd(DIDEFAULTFOLD, local_isum_list+i*2*DIDEFAULTFOLD, 1, local_isum_list+(2*i+1)*DIDEFAULTFOLD, 1, local_isum, 1, local_isum+DIDEFAULTFOLD, 1);
        //if(binned_dindex(local_isum[0]) > binned_dindex(local_isum_list[2*i*DIDEFAULTFOLD])){
        //	bins = binned_dmbins(local_isum[0]);
        //	binned_dmdupdate(DIDEFAULTFOLD, local_isum[0], local_isum_list+i*2*DIDEFAULTFOLD, 1, local_isum_list+(2*i+1)*DIDEFAULTFOLD, 1);
        //}else{
        //	bins = binned_dmbins(local_isum_list[2*i*DIDEFAULTFOLD]);
        //	binned_dmdupdate(DIDEFAULTFOLD, local_isum_list[2*i*DIDEFAULTFOLD], local_isum, 1, local_isum+DIDEFAULTFOLD, 1);
        //}
        //printf("bins=0x%lx\n",bins);
        //printf("i=%d, bins[0] = %le\n",i,bins[0]);
        //for(int j=0;j<DIDEFAULTFOLD;j++){
  	//	local_isum[j] += (local_isum_list[2*i*DIDEFAULTFOLD+j] - bins[j]);
  	//	local_isum[DIDEFAULTFOLD+j] += local_isum_list[(2*i+1)*DIDEFAULTFOLD+j];
        //}
        //
        //binned_dmrenorm(DIDEFAULTFOLD, local_isum, 1, local_isum+DIDEFAULTFOLD, 1);
  }
  //time = toc();
  //printf("\nomp reduce time : %le\n",time);

  double_binned *isum = binned_dballoc(DIDEFAULTFOLD);
  MPI_Reduce(local_isum, isum, 1, binnedMPI_DOUBLE_BINNED(3), binnedMPI_DBDBADD(3), 0, MPI_COMM_WORLD);

  //free(local_x);
  double sum = 0;
  if(rank == 0)
	  sum = binned_ddbconv(3, isum);

  return sum;
}

int main(int argc, char** argv){
  int rank, size;
  //MPI_Init(&argc, &argv);
  MPI_Init(NULL,NULL);
  MPI_Comm_rank(MPI_COMM_WORLD, &rank);
  MPI_Comm_size(MPI_COMM_WORLD, &size);
  //printf("rank=%d,siae=%d\n",rank,size);

  //int n = 50000000;
  int n = (argc==2?atol(argv[1]):10000000);
  n = (n+size-1)/size*size;
  //n = n + size - (n % size);
  int local_n = n / size;
  double elapsed_time1,elapsed_time2;
  double *x = NULL;
  double *x_shuffled = NULL;
  double *local_x = (double *)malloc(local_n * sizeof(double));
  double *local_x_shuffled = (double *)malloc(local_n * sizeof(double));

  if(rank == 0){
    x = (double *)malloc(n * sizeof(double));
    x_shuffled = (double *)malloc(n * sizeof(double));
    double rsum = 0.;
    // Set x to be a sine wave
    for(int i = 0; i < n; i++){
      x[i] = sin(2 * M_PI * ( i / (double)n - 0.5));
      rsum += x[i];
      //printf("x[%d] = %le\n",i,x[i]);
    }
    printf("rusm = %le x[last]=%le\n",rsum,x[n-1]);
    // Shuffle x into x_shuffled
    for(int i = 0; i < n; i++){
      x_shuffled[i] = x[i];
    }
    double t;
    int r;
    for(int i = 0; i < n; i++){
      r = rand();
      t = x_shuffled[i];
      x_shuffled[i] = x_shuffled[i + (r % (n - i))];
      x_shuffled[i + (r % (n - i))] = t;
    }
  }

  MPI_Scatter(x, local_n, MPI_DOUBLE, local_x, local_n, MPI_DOUBLE, 0, MPI_COMM_WORLD);
  MPI_Scatter(x_shuffled, local_n, MPI_DOUBLE, local_x_shuffled, local_n, MPI_DOUBLE, 0, MPI_COMM_WORLD);

  double mpfrsum = 0;
  if(rank == 0){
    printf("Sum of sin(2* M_PI * (i / (double)n - 0.5)).  n = %d.\n\n", n);

    mpfr_t s,t;
    mpfr_init2(t,200);
    mpfr_init2(s,200);
    mpfr_set_d(s, 0.0, MPFR_RNDD);

    for(int i=0;i<n;i++){
    	mpfr_set_d(t, x[i], MPFR_RNDD);
	mpfr_add(s, s, t, MPFR_RNDD);
    }
    mpfrsum = mpfr_get_d(s, MPFR_RNDD);
    mpfr_clear(s);
    mpfr_clear(t);
  }

  double local_sum = 0, local_repro_sum = 0, sum = 0, repro_sum = 0, sum_shuffled=0, repro_sum_shuffled=0;
  //printf("rank=%d,ldd local_x=%lx, ldd x=%lx,  err=%d\n",rank,local_x,x,checkarr(local_n,local_x,x+rank*local_n));
  //printf("rank=%d,local_sum = %le,local_repro_sum=%le\n",rank,local_sum,local_repro_sum);
  tic();
  repro_sum = MPI_Reprosum(local_x, local_n, 1);
  elapsed_time1 = toc();
  //printf("rank=%d,local_sum = %le,local_repro_sum=%le\n",rank,local_sum,local_repro_sum);

  tic();
  for(int i = 0; i < local_n; i++)
    local_sum += local_x[i];
  MPI_Reduce(&local_sum, &sum, 1, MPI_DOUBLE, MPI_SUM, 0, MPI_COMM_WORLD);
  elapsed_time2 = toc();
  //printf("rank = %d, local_sum = %le\n",rank,local_sum);
  //printf("rank=%d,sum = %le,repro_sum = %le\n",rank,sum,repro_sum);

  local_sum = 0;
  //printf("rank=%d,local_sum = %le,local_repro_sum=%le\n",rank,local_sum,local_repro_sum);
  repro_sum_shuffled = MPI_Reprosum(local_x_shuffled, local_n, 1);

  for(int i = 0; i < local_n; i++){
    local_sum += local_x_shuffled[i];
  }
  MPI_Reduce(&local_sum, &sum_shuffled, 1, MPI_DOUBLE, MPI_SUM, 0, MPI_COMM_WORLD);
//  printf("rank=%d,sum_shuffled = %le,repro_sum_shuffled = %le\n",rank,sum_shuffled,repro_sum_shuffled);

//  MPI_Reduce(&local_sum_shuffled, &sum_shuffled, 1, MPI_DOUBLE, MPI_SUM, 0, MPI_COMM_WORLD);
//  MPI_Reduce_Reprosum(&local_repro_sum_shuffled, &repro_sum_shuffled, 1, MPI_DOUBLE, MPI_SUM, 0, MPI_COMM_WORLD, 2);

  if(rank == 0){
    printf("Sum : %-g : |%.17e - %.17e| = %g\n",elapsed_time2, sum, sum_shuffled, fabs(sum - sum_shuffled));
    printf("Reprosum : %-g : |%.17e - %.17e| = %g\n", elapsed_time1, repro_sum, repro_sum_shuffled, fabs(repro_sum - repro_sum_shuffled));
    printf("Sum/Sum(mprf) |%.17e - %.17e|\nAbsolute error is %g\nRelative error is %g\n",sum,mpfrsum,fabs(sum - mpfrsum),fabs(sum - mpfrsum)/mpfrsum);
    printf("Reprosum/Sum(mprf) |%.17e - %.17e|\nAbsolute error is %g\nRelative error is %g\n",repro_sum,mpfrsum,fabs(repro_sum - mpfrsum),fabs(repro_sum - mpfrsum)/mpfrsum);
  }

  if(rank == 0){
    free(x);
    free(x_shuffled);
  }
  free(local_x);
  free(local_x_shuffled);
  MPI_Finalize();
}
