
task_suff=OmpxMpi
time_suff=`date "+%Y%m%d%H%M%S"`
#export PATH=/opt/mpi3/bin:${PATH}
LOGDIR=x86_log_${task_suff}_${time_suff}

mkdir -p ${LOGDIR}

for omp_threads in 1 4 8 12 16 32 64
#for omp_threads in 2
do
    for mpi_threads in 4 8 12 16 32 64
    #for mpi_threads in 1
    do
        export OMP_NUM_THREADS=${omp_threads}
        for i in `seq 1 20`
        do
            echo
            echo "mpi_threads=${mpi_threads} omp_threads=${omp_threads} cycle=${i}"
            mpirun -np ${mpi_threads} ./MPI_Reduce_Reprosum 50000000
        done > ${LOGDIR}/mpi${mpi_threads}_omp${omp_threads}.log 2>&1
    done
done

#n="100000 1000000 5000000 10000000 15000000 20000000 25000000 30000000 35000000 40000000 45000000 50000000 55000000 60000000 65000000 70000000 75000000 80000000 85000000 90000000 95000000 100000000"
#for i in `seq 4 22`
#do
#	n[$i]=$((${n[$((i-1))]}+${n[3]}))
#done

#echo ${n[@]}
#export OMP_NUM_THREADS=1
#for i in `echo ${n}`
#do
#	for j in `seq 1 10`
#	do
#		echo
#		echo "n=$i cycle=$j"
#		#cmd="mpirun -np 1 ./MPI_Reduce_Reprosum_nosimd ${i} &>> ${LOGDIR}/nosimd_n${i}_omp1mpi1.log"
#		mpirun -np 1 ./MPI_Reduce_Reprosum_nosimd ${i}
#		#echo ${cmd} | awk '{system($0)}' &
#	done > ${LOGDIR}/nosimd_n${i}_omp1mpi1.log 2>&1
#done 
#
#export OMP_NUM_THREADS=1
#for i in `echo ${n}`
#do
#	for j in `seq 1 10`
#	do
#		echo
#		echo "n=$i cycle=$j"
#		#cmd="mpirun -np 1 ./MPI_Reduce_Reprosum_simd ${i} &>> ${LOGDIR}/simd_n${i}_omp1mpi1.log"
#        mpirun -np 1 ./MPI_Reduce_Reprosum_simd ${i}
#		#echo ${cmd} | awk '{system($0)}' 
#	done > ${LOGDIR}/simd_n${i}_omp1mpi1.log 2>&1
#done 

#export OMP_NUM_THREADS=8
#for i in `echo ${n}`
#do
#	for j in `seq 1 10`
#	do
#		echo
#        echo "n=$i cycle=$j"
#		mpirun -np 1 ./MPI_Reduce_Reprosum ${i}
#	done > ${LOGDIR}/nosimd_n${i}_omp8mpi1.log 2>&1
#done 
#
#export OMP_NUM_THREADS=1
#for i in `echo ${n}`
#do
#	for j in `seq 1 10`
#	do
#		echo
#        echo "n=$i cycle=$j"
#		mpirun -np 8 ./MPI_Reduce_Reprosum ${i}
#	done > ${LOGDIR}/nosimd_n${i}_omp1mpi8.log 2>&1
#done
